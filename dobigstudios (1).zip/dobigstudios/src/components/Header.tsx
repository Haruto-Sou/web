'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';

const navLinks = [
  { label: 'Projects', href: '#projects' },
  { label: 'UE5', href: '#ue5' },
  { label: 'About', href: '#about' },
  { label: 'Team', href: '#team' },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [menuOpen]);

  const handleNavClick = () => setMenuOpen(false);

  return (
    <>
      <header
        className="fixed top-0 w-full z-50 transition-all duration-500"
        style={{
          background: scrolled
            ? 'rgba(5, 5, 8, 0.85)'
            : 'transparent',
          backdropFilter: scrolled ? 'blur(20px)' : 'none',
          borderBottom: scrolled ? '1px solid rgba(255,255,255,0.06)' : 'none',
        }}
      >
        <nav className="max-w-7xl mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <AppLogo size={36} />
            <span className="font-display font-semibold text-lg tracking-tight text-foreground group-hover:text-primary transition-colors duration-300">
Morgan Studios
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-10">
            {navLinks?.map((link) => (
              <a
                key={link?.label}
                href={link?.href}
                className="animated-underline text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors duration-300"
              >
                {link?.label}
              </a>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href="#contact"
              className="btn-primary rounded-sm"
            >
              Contact Us
            </a>
          </div>

          {/* Mobile Hamburger */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            <span
              className="block w-6 h-px bg-foreground transition-all duration-300"
              style={{ transform: menuOpen ? 'rotate(45deg) translateY(4px)' : 'none' }}
            />
            <span
              className="block w-6 h-px bg-foreground transition-all duration-300"
              style={{ opacity: menuOpen ? 0 : 1 }}
            />
            <span
              className="block w-6 h-px bg-foreground transition-all duration-300"
              style={{ transform: menuOpen ? 'rotate(-45deg) translateY(-4px)' : 'none' }}
            />
          </button>
        </nav>
      </header>
      {/* Mobile Menu Overlay */}
      {menuOpen && (
        <div
          className="fixed inset-0 z-40 flex flex-col justify-center items-center"
          style={{ background: 'rgba(5, 5, 8, 0.97)', backdropFilter: 'blur(24px)' }}
        >
          <nav className="flex flex-col items-center gap-8">
            {navLinks?.map((link, i) => (
              <a
                key={link?.label}
                href={link?.href}
                onClick={handleNavClick}
                className="font-display text-4xl font-light text-foreground hover:text-primary transition-colors duration-300"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                {link?.label}
              </a>
            ))}
            <a
              href="#contact"
              onClick={handleNavClick}
              className="btn-primary rounded-sm mt-4"
            >
              Contact Us
            </a>
          </nav>
        </div>
      )}
    </>
  );
}