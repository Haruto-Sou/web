import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from '@/app/components/HeroSection';
import RobloxProjects from '@/app/components/RobloxProjects';
import UE5Projects from '@/app/components/UE5Projects';
import AboutStats from '@/app/components/AboutStats';
import TeamSection from '@/app/components/TeamSection';
import ContactSection from '@/app/components/ContactSection';

export default function HomePage() {
  return (
    <>
      <div className="noise-overlay" aria-hidden="true" />
      <Header />
      <main>
        <HeroSection />
        <RobloxProjects />
        <UE5Projects />
        <AboutStats />
        <TeamSection />
        <ContactSection />
      </main>
      <Footer />
    </>
  );
}