'use client';
import React, { useState, useRef, useEffect } from 'react';

const socialLinks = [
  {
    name: 'Discord',
    label: 'Join our server',
    href: 'https://discord.com/invite/AMMRM495U2',
    color: '#5865F2',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.1 18.082.114 18.1.128 18.116a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
      </svg>
    ),
  },
  {
    name: 'Roblox',
    label: 'Play our games',
    href: 'https://www.roblox.com/es/games/109983668079237/Steal-a-Brainrot',
    color: '#FF3B30',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M4.597 0L0 19.403 19.403 24 24 4.597zm11.26 13.608l-5.464 1.461-1.46-5.464 5.464-1.46z"/>
      </svg>
    ),
  },
];

export default function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    type: 'general',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // UI-only mock submit — backend integration point
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="py-20 md:py-28 px-6 md:px-12 relative overflow-hidden"
      style={{ background: 'var(--background)' }}
    >
      {/* Atmospheric backdrop */}
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
        style={{
          background: 'radial-gradient(ellipse 60% 50% at 50% 100%, rgba(0,229,255,0.04) 0%, transparent 70%)',
        }}
      />

      <div className="section-divider mb-16" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-px" style={{ background: 'var(--primary)' }} />
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--primary)' }}>
              Get in Touch
            </span>
            <div className="w-8 h-px" style={{ background: 'var(--primary)' }} />
          </div>
          <h2
            className={`font-display text-section-title text-foreground transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          >
            Let&apos;s Build <br />
            <span className="italic font-light gradient-text-cyan">Something Big</span>
          </h2>
          <p className="text-sm text-muted-foreground mt-4 max-w-md mx-auto leading-relaxed">
            Whether you&apos;re a developer looking to partner, a creator wanting to collaborate, or a player with feedback — we want to hear from you.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Form — col-span-3 */}
          <div className="lg:col-span-3">
            {/* Terminal header */}
            <div
              className="rounded-sm overflow-hidden"
              style={{ border: '1px solid rgba(0,229,255,0.15)' }}
            >
              <div
                className="flex items-center gap-2 px-5 py-3"
                style={{ background: 'rgba(0,229,255,0.05)', borderBottom: '1px solid rgba(0,229,255,0.1)' }}
              >
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: 'rgba(0,229,255,0.4)' }} />
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: 'rgba(124,58,237,0.4)' }} />
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: 'rgba(255,255,255,0.2)' }} />
                <span className="text-xs text-muted-foreground ml-2 font-mono">contact@dobigstudios.com</span>
              </div>

              <div className="p-6 md:p-8" style={{ background: 'rgba(5,5,8,0.8)' }}>
                {submitted ? (
                  <div className="flex flex-col items-center justify-center py-12 gap-4">
                    <div
                      className="w-14 h-14 rounded-full flex items-center justify-center"
                      style={{ background: 'rgba(0,229,255,0.1)', border: '1px solid rgba(0,229,255,0.3)' }}
                    >
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2">
                        <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </div>
                    <div className="text-center">
                      <div className="font-display text-xl font-semibold text-foreground mb-1">Message Sent</div>
                      <div className="text-sm text-muted-foreground">We&apos;ll get back to you within 24 hours.</div>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Progress */}
                    <div className="flex items-center gap-2 mb-8">
                      <span className="text-xs text-muted-foreground font-mono">01</span>
                      <div className="h-px flex-1" style={{ background: 'rgba(255,255,255,0.08)' }}>
                        <div className="h-full transition-all duration-300" style={{ width: formState.message ? '100%' : formState.email ? '66%' : formState.name ? '33%' : '0%', background: 'var(--primary)' }} />
                      </div>
                      <span className="text-xs text-muted-foreground font-mono">03</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Full Name</label>
                        <input
                          type="text"
                          required
                          value={formState.name}
                          onChange={(e) => setFormState((s) => ({ ...s, name: e.target.value }))}
                          placeholder="Your name"
                          className="w-full bg-transparent border-b py-3 text-sm text-foreground focus:outline-none placeholder-zinc-700 transition-colors duration-300"
                          style={{ borderColor: 'rgba(255,255,255,0.1)' }}
                          onFocus={(e) => (e.currentTarget.style.borderColor = 'rgba(0,229,255,0.5)')}
                          onBlur={(e) => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)')}
                        />
                      </div>
                      <div>
                        <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Email</label>
                        <input
                          type="email"
                          required
                          value={formState.email}
                          onChange={(e) => setFormState((s) => ({ ...s, email: e.target.value }))}
                          placeholder="you@example.com"
                          className="w-full bg-transparent border-b py-3 text-sm text-foreground focus:outline-none placeholder-zinc-700 transition-colors duration-300"
                          style={{ borderColor: 'rgba(255,255,255,0.1)' }}
                          onFocus={(e) => (e.currentTarget.style.borderColor = 'rgba(0,229,255,0.5)')}
                          onBlur={(e) => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)')}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Inquiry Type</label>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        {[
                          { value: 'general', label: 'General' },
                          { value: 'partnership', label: 'Partnership' },
                          { value: 'acquisition', label: 'Acquisition' },
                          { value: 'career', label: 'Careers' },
                        ].map((opt) => (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() => setFormState((s) => ({ ...s, type: opt.value }))}
                            className="py-2.5 px-3 text-xs font-semibold uppercase tracking-wider rounded-sm transition-all duration-200"
                            style={{
                              background: formState.type === opt.value ? 'rgba(0,229,255,0.1)' : 'rgba(255,255,255,0.03)',
                              border: formState.type === opt.value ? '1px solid rgba(0,229,255,0.35)' : '1px solid rgba(255,255,255,0.07)',
                              color: formState.type === opt.value ? 'var(--primary)' : 'var(--muted-foreground)',
                            }}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">Message</label>
                      <textarea
                        required
                        rows={4}
                        value={formState.message}
                        onChange={(e) => setFormState((s) => ({ ...s, message: e.target.value }))}
                        placeholder="Tell us what you're building..."
                        className="w-full bg-transparent border-b py-3 text-sm text-foreground focus:outline-none placeholder-zinc-700 resize-none transition-colors duration-300"
                        style={{ borderColor: 'rgba(255,255,255,0.1)' }}
                        onFocus={(e) => (e.currentTarget.style.borderColor = 'rgba(0,229,255,0.5)')}
                        onBlur={(e) => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)')}
                      />
                    </div>

                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-2">
                      <p className="text-xs text-muted-foreground max-w-xs">
                        We respond to all inquiries within 24 hours. Acquisitions reviewed within 3 business days.
                      </p>
                      <button type="submit" className="btn-primary rounded-sm flex items-center gap-2 whitespace-nowrap">
                        Send Message
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M5 12h14M12 5l7 7-7 7"/>
                        </svg>
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          </div>

          {/* Right: Social + Info — col-span-2 */}
          <div className="lg:col-span-2 flex flex-col gap-5">
            {/* Social links */}
            <div
              className="p-6 rounded-sm"
              style={{ background: 'var(--card)', border: '1px solid rgba(255,255,255,0.06)' }}
            >
              <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-5">Connect with us</h3>
              <div className="grid grid-cols-2 gap-3">
                {socialLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href || '#'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 rounded-sm group transition-all duration-300"
                    style={{
                      background: 'rgba(255,255,255,0.02)',
                      border: '1px solid rgba(255,255,255,0.06)',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = `${link.color}40`;
                      e.currentTarget.style.background = `${link.color}08`;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)';
                      e.currentTarget.style.background = 'rgba(255,255,255,0.02)';
                    }}
                  >
                    <span style={{ color: link.color }}>{link.icon}</span>
                    <div>
                      <div className="text-xs font-semibold text-foreground">{link.name}</div>
                      <div className="text-xs text-muted-foreground">{link.label}</div>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {/* Game Jam CTA */}
            <div
              className="p-6 rounded-sm relative overflow-hidden"
              style={{
                background: 'linear-gradient(135deg, rgba(0,229,255,0.06) 0%, rgba(124,58,237,0.08) 100%)',
                border: '1px solid rgba(0,229,255,0.15)',
              }}
            >
              <div
                className="absolute top-0 right-0 w-32 h-32 pointer-events-none"
                style={{ background: 'radial-gradient(circle, rgba(0,229,255,0.08) 0%, transparent 70%)' }}
                aria-hidden="true"
              />
              <div className="relative z-10">
                <span className="tag-badge status-active mb-3 inline-block">Next Game Jam</span>
                <h3 className="font-display text-xl font-semibold text-foreground mb-2">MST Game Jam</h3>
                <p className="text-xs text-muted-foreground leading-relaxed mb-4">
                  24-hour global competition. Build a Roblox game from scratch. Prize pool: <span className="text-primary font-semibold">$65,000</span>
                </p>
                <a href="#" className="btn-primary rounded-sm text-xs inline-flex items-center gap-2">
                  Register Interest
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </a>
              </div>
            </div>

            {/* Quick info */}
            <div
              className="p-5 rounded-sm"
              style={{ background: 'var(--card)', border: '1px solid rgba(255,255,255,0.06)' }}
            >
              <div className="space-y-3">
                {[
                  { label: 'Founded', value: 'May 15, 2023' },
                  { label: 'Headquarters', value: 'United States' },
                  { label: 'Email', value: 'contactmorganstud@gmail.com' },
                  { label: 'Platform', value: 'Roblox & Unreal Engine 5' },
                ].map((item) => (
                  <div key={item.label} className="flex justify-between items-center py-2 border-b" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
                    <span className="text-xs text-muted-foreground">{item.label}</span>
                    <span className="text-xs font-medium text-foreground">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}