'use client';
import React, { useRef, useState, useEffect } from 'react';
import AppImage from '@/components/ui/AppImage';

const projects = [
{
  id: 'peak-seas',
  name: 'Peak Seas',
  description: 'An epic naval adventure set across vast open oceans. Command your ship, battle rival crews, and discover uncharted islands in a dynamic world of wind and waves.',
  genre: 'Adventure / Naval',
  players: '25K+ daily',
  visits: '500M+ visits',
  status: 'active' as const,
  image: "https://images.unsplash.com/photo-1513448988970-0d6e0dad6177",
  alt: 'Dramatic ocean scene with stormy waves and a ship silhouette against a dark sky with lightning',
  featured: true
},
{
  id: 'steal-a-brainrot',
  name: 'Steal A Brainrot',
  description: 'A chaotic and hilarious heist game where players compete to steal the most absurd brainrot items. Fast-paced, unpredictable, and endlessly entertaining.',
  genre: 'Comedy / PvP',
  players: '18K+ daily',
  visits: '200M+ visits',
  status: 'active' as const,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1e4cb2e84-1771536051611.png",
  alt: 'Colorful chaotic game environment with bright neon colors and playful cartoon-style elements',
  featured: false
},
{
  id: 'terraform',
  name: 'Terraform',
  description: 'A large-scale planetary building simulator where players reshape alien worlds. Mine resources, engineer ecosystems, and transform barren landscapes into thriving civilizations.',
  genre: 'Simulation / Strategy',
  players: '15K+ daily',
  visits: '150M+ visits',
  status: 'active' as const,
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_150e0e4b3-1772728751318.png",
  alt: 'Alien planet surface with dramatic terrain, glowing atmosphere and futuristic structures under a starry sky',
  featured: false
}];


function ProjectCard({
  project,
  className = '',
  large = false




}: {project: typeof projects[0];className?: string;large?: boolean;}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 14;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -14;
    setTilt({ x, y });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
    setHovered(false);
  };

  const statusClass = project.status === 'active' ? 'status-active' : project.status === 'beta' ? 'status-beta' : 'status-dev';

  return (
    <div
      ref={cardRef}
      className={`relative overflow-hidden rounded-sm cursor-pointer group ${className}`}
      style={{
        transform: `perspective(1000px) rotateX(${tilt.y}deg) rotateY(${tilt.x}deg)`,
        transition: hovered ? 'transform 0.1s ease' : 'transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        background: 'var(--card)',
        border: hovered ? '1px solid rgba(0,229,255,0.25)' : '1px solid rgba(255,255,255,0.06)',
        boxShadow: hovered ? '0 0 40px rgba(0,229,255,0.1), 0 20px 60px rgba(0,0,0,0.5)' : '0 4px 20px rgba(0,0,0,0.4)'
      }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={handleMouseLeave}>
      
      {/* Image */}
      <div className={`relative overflow-hidden ${large ? 'h-72 md:h-80' : 'h-44 md:h-52'}`}>
        <AppImage
          src={project.image}
          alt={project.alt}
          fill
          sizes="(max-width: 768px) 100vw, 50vw"
          className="object-cover transition-transform duration-700 group-hover:scale-110" />
        
        <div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(to top, rgba(5,5,8,0.95) 0%, rgba(5,5,8,0.4) 50%, rgba(5,5,8,0.1) 100%)'
          }} />
        
        {project.record &&
        <div className="absolute top-3 right-3">
            <span className="tag-badge status-active flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              {project.record}
            </span>
          </div>
        }
        <div className="absolute top-3 left-3">
          <span className={`tag-badge ${statusClass}`}>
            {project.status === 'active' ? 'Live' : project.status === 'beta' ? 'Beta' : 'In Dev'}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <div className="flex items-start justify-between mb-2">
          <h3 className={`font-display font-semibold text-foreground ${large ? 'text-2xl' : 'text-lg'}`}>
            {project.name}
          </h3>
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            className="text-muted-foreground group-hover:text-primary group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-all duration-300 shrink-0 mt-1">
            
            <path d="M7 17L17 7M7 7h10v10" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>

        <p className="text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-2">
          {project.description}
        </p>

        <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
            {project.players}
          </span>
          <span className="flex items-center gap-1">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
            </svg>
            {project.visits}
          </span>
          <span
            className="px-2 py-0.5 rounded-sm text-xs"
            style={{ background: 'rgba(255,255,255,0.05)', color: 'var(--muted-foreground)' }}>
            
            {project.genre}
          </span>
        </div>
      </div>
    </div>);

}

export default function RobloxProjects() {
  const sectionRef = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {if (entry.isIntersecting) setVisible(true);},
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="projects"
      ref={sectionRef}
      className="py-20 md:py-28 px-6 md:px-12 relative overflow-hidden"
      style={{ background: 'var(--background)' }}>
      
      <div className="section-divider mb-16" />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-px" style={{ background: 'var(--primary)' }} />
              <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--primary)' }}>
                Roblox Portfolio
              </span>
            </div>
            <h2
              className={`font-display text-section-title text-foreground transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              
              Games That <br />
              <span className="italic font-light gradient-text-cyan">Broke Records</span>
            </h2>
          </div>
          <p className="text-sm text-muted-foreground max-w-sm leading-relaxed">
            From idle simulations to competitive PvP — our titles have collectively generated over 12 billion visits on Roblox.
          </p>
        </div>

        {/* Bento Grid
            Row 1: [col-1-2: PeakSeas cs-2 rs-2] [col-3: StealABrainrot cs-1]
            Row 2: [col-1-2: FILLED]              [col-3: Terraform cs-1]
            Placed 3/3 cards ✓
           */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* PeakSeas — col-span-2 row-span-2 */}
          <div className="md:col-span-2 md:row-span-2">
            <ProjectCard project={projects[0]} large className="h-full" />
          </div>

          {/* StealABrainrot — col-span-1 */}
          <div>
            <ProjectCard project={projects[1]} />
          </div>

          {/* Terraform — col-span-1 */}
          <div>
            <ProjectCard project={projects[2]} />
          </div>
        </div>
      </div>
    </section>);

}