'use client';
import React, { useRef, useState, useEffect } from 'react';
import AppImage from '@/components/ui/AppImage';

const ue5Projects = [
{
  id: 'zelda-ocarina-remake',
  name: 'The Legend of Zelda: Ocarina of Time Remake',
  type: 'Remake',
  description: 'A stunning high-fidelity remake of the classic N64 masterpiece, rebuilt from the ground up in Unreal Engine 5 with Lumen lighting and Nanite geometry.',
  tech: ['Lumen GI', 'Nanite', 'MetaHuman', 'Chaos Physics'],
  status: 'In Production',
  duration: 'Full Game',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_11a8b693a-1772080444854.png",
  alt: 'Mystical fantasy landscape with glowing golden light, ancient ruins and lush green environment reminiscent of Hyrule'
},
{
  id: 'zelda-twilight-princess',
  name: 'The Legend of Zelda: Twilight Princess',
  type: 'Action RPG',
  description: 'An epic dark fantasy adventure following Link as he battles to save Hyrule from the twilight realm, featuring dynamic combat and a vast open world.',
  tech: ['PCG Framework', 'Niagara VFX', 'Motion Warping', 'World Partition'],
  status: 'In Production',
  duration: 'Full Game',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_119a4da4b-1772880236650.png",
  alt: 'Dark fantasy forest environment with dramatic moody lighting, twilight atmosphere and ancient mystical structures'
},
{
  id: 'void-render',
  name: 'Void Render',
  type: 'Architectural Viz',
  description: 'High-fidelity architectural visualization of a next-gen gaming facility. Real-time ray tracing with fully interactive lighting.',
  tech: ['Ray Tracing', 'Datasmith', 'DLSS 3', 'Virtual Shadow Maps'],
  status: 'Completed',
  duration: '360° walkthrough',
  image: "https://images.unsplash.com/photo-1579458232906-bf695e66ae87",
  alt: 'Sleek modern architectural interior with ambient purple and blue lighting, deep space aesthetic, dark polished surfaces'
}];


function UE5Card({ project, index }: {project: typeof ue5Projects[0];index: number;}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [hovered, setHovered] = useState(false);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 10;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -10;
    setTilt({ x, y });
  };

  return (
    <div
      ref={cardRef}
      className="relative overflow-hidden rounded-sm group cursor-pointer opacity-100 animate-fade-in-up"
      style={{
        animationDelay: `${index * 150}ms`,
        animationFillMode: 'forwards',
        background: 'var(--card)',
        border: hovered ? '1px solid rgba(124,58,237,0.3)' : '1px solid rgba(255,255,255,0.06)',
        boxShadow: hovered ? '0 0 40px rgba(124,58,237,0.12), 0 20px 60px rgba(0,0,0,0.6)' : '0 4px 20px rgba(0,0,0,0.4)',
        transform: `perspective(1000px) rotateX(${tilt.y}deg) rotateY(${tilt.x}deg)`,
        transition: hovered ? 'transform 0.1s ease, box-shadow 0.3s ease, border-color 0.3s ease' : 'transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94), box-shadow 0.3s ease, border-color 0.3s ease'
      }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => {setTilt({ x: 0, y: 0 });setHovered(false);}}>
      
      {/* Image */}
      <div className="relative h-56 overflow-hidden">
        <AppImage
          src={project.image}
          alt={project.alt}
          fill
          sizes="(max-width: 768px) 100vw, 33vw"
          className="object-cover transition-transform duration-1000 group-hover:scale-110" />
        
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(to top, rgba(10,10,18,1) 0%, rgba(10,10,18,0.3) 60%, transparent 100%)' }} />
        

        {/* Play overlay */}
        <div
          className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          style={{ background: 'rgba(0,0,0,0.3)' }}>
          
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center"
            style={{
              background: 'rgba(124,58,237,0.8)',
              backdropFilter: 'blur(8px)',
              boxShadow: '0 0 30px rgba(124,58,237,0.5)'
            }}>
            
            <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </div>

        <div className="absolute top-3 left-3">
          <span className="tag-badge status-dev">{project.type}</span>
        </div>
        <div className="absolute top-3 right-3">
          <span className="tag-badge" style={{ background: 'rgba(0,0,0,0.6)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.1)' }}>
            {project.duration}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-display text-xl font-semibold text-foreground">{project.name}</h3>
          <svg
            width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"
            className="text-muted-foreground group-hover:text-accent group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-all duration-300 shrink-0 mt-1">
            
            <path d="M7 17L17 7M7 7h10v10" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>

        <p className="text-sm text-muted-foreground leading-relaxed mb-4">{project.description}</p>

        {/* Tech stack */}
        <div className="flex flex-wrap gap-2">
          {project.tech.map((t) =>
          <span
            key={t}
            className="tag-badge"
            style={{ background: 'rgba(124,58,237,0.08)', color: '#A78BFA', border: '1px solid rgba(124,58,237,0.2)' }}>
            
              {t}
            </span>
          )}
        </div>

        <div className="mt-4 pt-4 flex items-center justify-between" style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
          <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{project.status}</span>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: project.status === 'Completed' ? '#00E5FF' : project.status === 'Alpha' ? '#FCD34D' : '#A78BFA' }} />
            <span className="text-xs text-muted-foreground">UE5</span>
          </div>
        </div>
      </div>
    </div>);

}

export default function UE5Projects() {
  const sectionRef = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {if (entry.isIntersecting) setVisible(true);},
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="ue5"
      ref={sectionRef}
      className="py-20 md:py-28 px-6 md:px-12 relative overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, var(--background) 0%, rgba(10,5,20,1) 50%, var(--background) 100%)'
      }}>
      
      {/* Atmospheric accent */}
      <div
        className="absolute top-0 left-0 w-full h-full pointer-events-none"
        aria-hidden="true"
        style={{
          background: 'radial-gradient(ellipse 70% 50% at 50% 50%, rgba(124,58,237,0.06) 0%, transparent 70%)'
        }} />
      

      <div className="section-divider mb-16" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-px" style={{ background: 'var(--accent)' }} />
              <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--accent)' }}>
                Unreal Engine 5
              </span>
            </div>
            <h2
              className={`font-display text-section-title text-foreground transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              
              AAA-Grade <br />
              <span className="italic font-light neon-text-violet">Experiences</span>
            </h2>
          </div>
          <div className="max-w-sm">
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              Pushing the boundaries of real-time rendering with Lumen, Nanite, and next-gen pipeline tools.
            </p>
            <div
              className="flex items-center gap-3 px-4 py-3 rounded-sm"
              style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.2)' }}>
              
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#A78BFA" strokeWidth="1.5">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
              <span className="text-xs font-semibold text-accent">Fortnite Map Partnership — Steal The Brainrot</span>
            </div>
          </div>
        </div>

        {/* Grid — 3 uniform cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {ue5Projects.map((project, index) =>
          <UE5Card key={project.id} project={project} index={index} />
          )}
        </div>

        {/* Tech strip */}
        <div
          className="mt-10 p-5 rounded-sm flex flex-wrap items-center gap-4 md:gap-8"
          style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)' }}>
          
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Powered by</span>
          {['Unreal Engine 5', 'Lumen', 'Nanite', 'MetaHuman', 'Niagara VFX', 'Chaos Physics'].map((tech) =>
          <span
            key={tech}
            className="text-xs font-medium"
            style={{ color: 'rgba(255,255,255,0.5)' }}>
            
              {tech}
            </span>
          )}
        </div>
      </div>
    </section>);

}