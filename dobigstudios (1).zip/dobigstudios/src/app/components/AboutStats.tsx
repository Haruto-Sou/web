'use client';
import React, { useRef, useState, useEffect } from 'react';

function useCountUp(target: number, duration: number, active: boolean) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!active) return;
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [active, target, duration]);

  return count;
}

const stats = [
  { label: 'Total Visits', value: 12, suffix: 'B+', description: 'Across all Roblox titles', color: 'var(--primary)' },
  { label: 'Peak Concurrent', value: 21, suffix: '.3M', description: 'Peak Seas world record', color: 'var(--primary)' },
  { label: 'Years Active', value: 2, suffix: '+', description: 'Founded May 15, 2023', color: '#A78BFA' },
  { label: 'Game Jam Prize', value: 65, suffix: 'K', prefix: '$', description: 'First MST Game Jam', color: '#A78BFA' },
];

function StatCard({ stat, active, index }: { stat: typeof stats[0]; active: boolean; index: number }) {
  const count = useCountUp(stat.value, 1800, active);
  return (
    <div
      className="p-6 rounded-sm relative overflow-hidden group opacity-100 animate-fade-in-up"
      style={{
        animationDelay: `${index * 120}ms`,
        animationFillMode: 'forwards',
        background: 'var(--card)',
        border: '1px solid rgba(255,255,255,0.06)',
      }}
    >
      <div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at 50% 100%, ${stat.color}10 0%, transparent 70%)`,
        }}
      />
      <div
        className="font-display font-bold mb-1 stat-counter-glow"
        style={{ fontSize: 'clamp(2.5rem, 5vw, 3.5rem)', color: stat.color, lineHeight: 1 }}
      >
        {stat.prefix || ''}{count}{stat.suffix}
      </div>
      <div className="text-sm font-semibold text-foreground mb-1">{stat.label}</div>
      <div className="text-xs text-muted-foreground">{stat.description}</div>
    </div>
  );
}

export default function AboutStats() {
  const sectionRef = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="py-20 md:py-28 px-6 md:px-12"
      style={{ background: 'var(--background)' }}
    >
      <div className="section-divider mb-16" />

      <div className="max-w-7xl mx-auto">
        {/* Split layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start mb-20">
          {/* Left: Story */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-px" style={{ background: 'var(--primary)' }} />
              <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--primary)' }}>
                Our Story
              </span>
            </div>
            <h2
              className={`font-display text-section-title text-foreground mb-6 transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
            >
              Built to <br />
              <span className="italic font-light gradient-text-cyan">Scale Games</span>
            </h2>
            <div className="space-y-5 text-muted-foreground leading-relaxed text-sm md:text-base" style={{ borderLeft: '1px solid rgba(255,255,255,0.08)', paddingLeft: '1.5rem' }}>
              <p>
                Founded on May 15, 2023 by CEO Miles Morgan — known online as <span className="text-foreground font-medium">heyxam22</span> — Morgan Studios began as a vision to transform how games are built, discovered, and scaled on Roblox.
              </p>
              <p>
                We partner with developers, can take over day-to-day operations, and offer a clean exit when developers are ready. When we acquire a game, we offer competitive sums with optional ongoing revenue-sharing models.
              </p>
              <p>
                On June 21, 2025, Peak Seas shattered all records with <span className="text-primary font-semibold">21.3 million concurrent users</span> — a moment that cemented Morgan Studios as the most influential force in Roblox gaming history.
              </p>
            </div>

            <div className="mt-8 flex flex-col gap-3">
              {[
                { icon: '⚡', text: 'Billions of visits across our portfolio' },
                { icon: '🎮', text: 'Fortnite x DBS partnership — all-time concurrent record' },
                { icon: '🏆', text: '$65,000 Game Jam prize pool — global competition' },
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-3">
                  <span className="text-lg">{item.icon}</span>
                  <span className="text-sm text-muted-foreground">{item.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Vision + Philosophy */}
          <div className="flex flex-col justify-between h-full gap-6">
            <div
              className="p-6 rounded-sm"
              style={{ background: 'rgba(0,229,255,0.04)', border: '1px solid rgba(0,229,255,0.12)' }}
            >
              <h3 className="font-display text-xl font-semibold text-foreground mb-3">Our Vision</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                To be the defining force that shapes the next generation of interactive entertainment — not just on Roblox, but across every platform where players live.
              </p>
            </div>

            <div
              className="p-6 rounded-sm"
              style={{ background: 'rgba(124,58,237,0.04)', border: '1px solid rgba(124,58,237,0.12)' }}
            >
              <h3 className="font-display text-xl font-semibold text-foreground mb-3">Development Philosophy</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                We reject "good enough." Every mechanic, every frame, every line of code is scrutinized. We build experiences that feel inevitable — games people play for years, not weeks.
              </p>
            </div>

            <div
              className="p-6 rounded-sm"
              style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}
            >
              <h3 className="font-display text-xl font-semibold text-foreground mb-3">For Developers</h3>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                Ready to exit or scale your game? We offer competitive acquisitions, revenue-sharing, and full operational support. Your game, amplified.
              </p>
              <a href="#contact" className="btn-ghost rounded-sm text-xs inline-flex items-center gap-2">
                Partner with us
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
              </a>
            </div>
          </div>
        </div>

        {/* Stats grid */}
        <div>
          <div className="flex items-center gap-3 mb-8">
            <div className="w-8 h-px" style={{ background: 'var(--primary)' }} />
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--primary)' }}>
              By the Numbers
            </span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <StatCard key={stat.label} stat={stat} active={visible} index={index} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}