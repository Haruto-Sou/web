'use client';
import React, { useEffect, useRef } from 'react';

export default function HeroSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let width = 0;
    let height = 0;

    const particles: Array<{
      x: number; y: number; vx: number; vy: number;
      size: number; opacity: number; color: string; pulse: number;
    }> = [];

    const COLORS = ['#00E5FF', '#7C3AED', '#00B4D8', '#5B21B6', '#06B6D4'];
    const PARTICLE_COUNT = 80;

    const resize = () => {
      width = canvas.offsetWidth;
      height = canvas.offsetHeight;
      canvas.width = width;
      canvas.height = height;
    };

    const init = () => {
      particles.length = 0;
      for (let i = 0; i < PARTICLE_COUNT; i++) {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
          size: Math.random() * 2 + 0.5,
          opacity: Math.random() * 0.6 + 0.1,
          color: COLORS[Math.floor(Math.random() * COLORS.length)],
          pulse: Math.random() * Math.PI * 2,
        });
      }
    };

    const drawConnections = () => {
      const maxDist = 120;
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < maxDist) {
            const alpha = (1 - dist / maxDist) * 0.12;
            ctx.beginPath();
            ctx.strokeStyle = `rgba(0, 229, 255, ${alpha})`;
            ctx.lineWidth = 0.5;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }
    };

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw nebula blobs
      const gradient1 = ctx.createRadialGradient(width * 0.2, height * 0.3, 0, width * 0.2, height * 0.3, width * 0.4);
      gradient1.addColorStop(0, 'rgba(0, 229, 255, 0.04)');
      gradient1.addColorStop(1, 'transparent');
      ctx.fillStyle = gradient1;
      ctx.fillRect(0, 0, width, height);

      const gradient2 = ctx.createRadialGradient(width * 0.8, height * 0.7, 0, width * 0.8, height * 0.7, width * 0.35);
      gradient2.addColorStop(0, 'rgba(124, 58, 237, 0.06)');
      gradient2.addColorStop(1, 'transparent');
      ctx.fillStyle = gradient2;
      ctx.fillRect(0, 0, width, height);

      drawConnections();

      particles.forEach((p) => {
        p.pulse += 0.02;
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        const currentOpacity = p.opacity * (0.7 + 0.3 * Math.sin(p.pulse));
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color + Math.floor(currentOpacity * 255).toString(16).padStart(2, '0');
        ctx.fill();

        // Glow
        const glow = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * 4);
        glow.addColorStop(0, p.color + '20');
        glow.addColorStop(1, 'transparent');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * 4, 0, Math.PI * 2);
        ctx.fill();
      });

      animationId = requestAnimationFrame(animate);
    };

    resize();
    init();
    animate();

    const resizeObserver = new ResizeObserver(() => { resize(); init(); });
    resizeObserver.observe(canvas);

    return () => {
      cancelAnimationFrame(animationId);
      resizeObserver.disconnect();
    };
  }, []);

  return (
    <section
      className="relative w-full min-h-screen flex items-center justify-center overflow-hidden"
      style={{ background: 'var(--background)' }}
    >
      {/* Canvas background */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        aria-hidden="true"
      />

      {/* Atmospheric depth layers */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-0 left-0 w-full h-full parallax-blob-1"
          style={{ width: '60%', height: '60%', top: '-10%', left: '-10%' }}
          aria-hidden="true"
        />
        <div
          className="absolute parallax-blob-2"
          style={{ width: '50%', height: '50%', bottom: '-5%', right: '-5%' }}
          aria-hidden="true"
        />
        <div
          className="absolute parallax-blob-3"
          style={{ width: '40%', height: '40%', top: '30%', left: '30%' }}
          aria-hidden="true"
        />
      </div>

      {/* Scan line effect */}
      <div
        className="absolute inset-0 pointer-events-none overflow-hidden"
        aria-hidden="true"
      >
        <div
          className="absolute w-full h-px opacity-5"
          style={{
            background: 'linear-gradient(90deg, transparent, rgba(0,229,255,0.8), transparent)',
            animation: 'scanLine 8s linear infinite',
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 pt-24 pb-20 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center min-h-[80vh]">

          {/* Left: Main Text */}
          <div className="lg:col-span-8 flex flex-col justify-center">
            <div
              className="flex items-center gap-4 mb-8 opacity-100 animate-fade-in-up"
              style={{ animationFillMode: 'forwards' }}
            >
              <div className="w-10 h-px" style={{ background: 'var(--primary)' }} />
              <span
                className="text-xs font-semibold uppercase tracking-widest"
                style={{ color: 'var(--primary)' }}
              >
                Est. 2020 · AAA Game Studio
              </span>
            </div>

            <h1
              className="font-display text-hero text-foreground leading-none mb-6 opacity-100 animate-fade-in-up delay-100"
              style={{ animationFillMode: 'forwards' }}
            >
              <span className="block">Morgan</span>
              <span className="block">Studios</span>
            </h1>

            <p
              className="text-lg md:text-xl font-light text-muted-foreground max-w-xl mb-10 leading-relaxed opacity-100 animate-fade-in-up delay-200"
              style={{ animationFillMode: 'forwards' }}
            >
              Creating immersive worlds and next-generation experiences. Behind the most-played Roblox titles on the platform.
            </p>

            <div
              className="flex flex-wrap gap-4 opacity-100 animate-fade-in-up delay-300"
              style={{ animationFillMode: 'forwards' }}
            >
              <a href="#projects" className="btn-primary rounded-sm flex items-center gap-2">
                Explore Projects
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
              </a>
              <a href="#about" className="btn-ghost rounded-sm">
                Our Story
              </a>
            </div>
          </div>

          {/* Right: Stats card */}
          <div
            className="lg:col-span-4 opacity-100 animate-fade-in-up delay-400"
            style={{ animationFillMode: 'forwards' }}
          >
            <div className="glass-card rounded-sm p-6 neon-border-cyan animate-border-glow">
              <div className="text-xs font-semibold uppercase tracking-widest mb-5" style={{ color: 'var(--primary)' }}>
                Live Stats
              </div>
              <div className="space-y-5">
                {[
                  { label: 'Total Game Visits', value: '12B+', sub: 'Across all titles' },
                  { label: 'Peak Concurrent', value: '21.3M', sub: 'Grow a Garden record' },
                  { label: 'Monthly Active', value: '100M+', sub: 'Users across portfolio' },
                  { label: 'Game Jam Prize', value: '$65K', sub: 'First MST Game Jam' },
                ].map((stat) => (
                  <div key={stat.label} className="flex items-start justify-between border-b pb-4" style={{ borderColor: 'rgba(255,255,255,0.06)' }}>
                    <div>
                      <div className="text-xs text-muted-foreground font-medium">{stat.label}</div>
                      <div className="text-xs text-muted-foreground mt-0.5 opacity-60">{stat.sub}</div>
                    </div>
                    <div className="font-display font-semibold text-xl neon-text-cyan">{stat.value}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <span className="text-xs uppercase tracking-widest text-muted-foreground">Scroll</span>
          <div
            className="w-px h-8"
            style={{
              background: 'linear-gradient(to bottom, rgba(0,229,255,0.6), transparent)',
              animation: 'floatY 2s ease-in-out infinite',
            }}
          />
        </div>
      </div>
    </section>
  );
}