'use client';
import React, { useRef, useState, useEffect } from 'react';

const teamMembers = [
{
  name: 'Miles Morgan',
  role: 'CEO & Founder',
  specialty: 'Vision & Studio Leadership',
  color: 'var(--primary)',
  icon: '⚙️',
  bio: 'Founded Morgan Studios on May 15, 2023. Known online as heyxam22. Visionary behind Peak Seas\' 21.3M concurrent users world record.'
},
{
  name: 'Madison Morgan',
  role: 'Creative Director',
  specialty: 'Brand & Visual Identity',
  color: '#A78BFA',
  icon: '🏗️',
  bio: 'Shapes the visual identity and creative direction of every Morgan Studios project.'
},
{
  name: 'Alexander Massimo',
  role: 'Lead Developer',
  specialty: 'Luau & Systems Architecture',
  color: '#00E5FF',
  icon: '🎨',
  bio: 'Core architect behind Morgan Studios\' server infrastructure and scalable game systems.'
},
{
  name: 'Marcos Lopez',
  role: 'World Builder',
  specialty: 'Environmental Design',
  color: '#F472B6',
  icon: '✨',
  bio: 'Crafts the expansive open worlds and immersive environments across all studio titles.'
},
{
  name: 'Sebastians Ramirez',
  role: 'VFX & Animator',
  specialty: 'Particles, Motion & Visual Effects',
  color: '#FCD34D',
  icon: '🎬',
  bio: 'Brings characters and worlds to life with stunning VFX and fluid animations across all Morgan Studios titles.'
}];


function TeamCard({ member, index }: {member: typeof teamMembers[0];index: number;}) {
  const [hovered, setHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 12;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -12;
    setTilt({ x, y });
  };

  return (
    <div
      ref={cardRef}
      className="relative overflow-hidden rounded-sm cursor-pointer group opacity-100 animate-fade-in-up"
      style={{
        animationDelay: `${index * 100}ms`,
        animationFillMode: 'forwards',
        background: 'var(--card)',
        border: hovered ? `1px solid ${member.color}30` : '1px solid rgba(255,255,255,0.06)',
        boxShadow: hovered ? `0 0 30px ${member.color}15, 0 15px 40px rgba(0,0,0,0.5)` : '0 4px 20px rgba(0,0,0,0.3)',
        transform: `perspective(800px) rotateX(${tilt.y}deg) rotateY(${tilt.x}deg)`,
        transition: hovered ?
        'transform 0.1s ease, box-shadow 0.3s ease, border-color 0.3s ease' :
        'transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94), box-shadow 0.3s ease, border-color 0.3s ease'
      }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => {setTilt({ x: 0, y: 0 });setHovered(false);}}>

      {/* Icon Header */}
      <div
        className="flex items-center justify-center h-32"
        style={{ background: `linear-gradient(135deg, ${member.color}15 0%, transparent 100%)` }}>
        <div
          className="w-16 h-16 flex items-center justify-center rounded-sm text-3xl"
          style={{
            background: `${member.color}20`,
            border: `1px solid ${member.color}40`
          }}>
          {member.icon}
        </div>
      </div>

      {/* Info */}
      <div className="p-5">
        <div className="mb-1">
          <h3 className="font-display text-lg font-semibold text-foreground">{member.name}</h3>
          <div className="text-xs font-bold uppercase tracking-widest mt-0.5" style={{ color: member.color }}>
            {member.role}
          </div>
        </div>
        <div className="text-xs text-muted-foreground mb-3">{member.specialty}</div>

        <div
          className="overflow-hidden transition-all duration-300"
          style={{ maxHeight: hovered ? '80px' : '0px', opacity: hovered ? 1 : 0 }}>
          
          <p className="text-xs text-muted-foreground leading-relaxed pt-2 border-t" style={{ borderColor: 'rgba(255,255,255,0.06)' }}>
            {member.bio}
          </p>
        </div>
      </div>
    </div>);

}

export default function TeamSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {if (entry.isIntersecting) setVisible(true);},
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="team"
      ref={sectionRef}
      className="py-20 md:py-28 px-6 md:px-12"
      style={{ background: 'var(--background)' }}>
      
      <div className="section-divider mb-16" />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-px" style={{ background: 'var(--primary)' }} />
              <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: 'var(--primary)' }}>
                The Team
              </span>
            </div>
            <h2
              className={`font-display text-section-title text-foreground transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              
              The People <br />
              <span className="italic font-light gradient-text-cyan">Behind It</span>
            </h2>
          </div>
          <div className="flex flex-col gap-3">
            <p className="text-sm text-muted-foreground max-w-sm leading-relaxed">
              A tight-knit crew of world-builders, coders, and artists obsessed with making unforgettable games.
            </p>
            <a
              href="#contact"
              className="btn-ghost rounded-sm text-xs inline-flex items-center gap-2 w-fit">
              
              Join the Studio
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {/* Row 1: 3 cards */}
          {teamMembers.slice(0, 3).map((member, i) =>
          <TeamCard key={member.name} member={member} index={i} />
          )}

          {/* Marcos Lopez — col-span-2 */}
          <div className="sm:col-span-2 md:col-span-2">
            <div
              className="relative overflow-hidden rounded-sm cursor-pointer group opacity-100 animate-fade-in-up h-full"
              style={{
                animationDelay: '300ms',
                animationFillMode: 'forwards',
                background: 'var(--card)',
                border: '1px solid rgba(255,255,255,0.06)',
                minHeight: '200px'
              }}>
              
              <div className="flex flex-col md:flex-row h-full">
                <div
                  className="flex items-center justify-center md:w-2/5 h-48 md:h-full"
                  style={{ background: `linear-gradient(135deg, ${teamMembers[3].color}15 0%, transparent 100%)` }}>
                  <div
                    className="w-20 h-20 flex items-center justify-center rounded-sm text-4xl"
                    style={{
                      background: `${teamMembers[3].color}20`,
                      border: `1px solid ${teamMembers[3].color}40`
                    }}>
                    {teamMembers[3].icon}
                  </div>
                </div>
                <div className="flex-1 p-6 flex flex-col justify-center">
                  <h3 className="font-display text-xl font-semibold text-foreground mb-1">{teamMembers[3].name}</h3>
                  <div className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: teamMembers[3].color }}>
                    {teamMembers[3].role}
                  </div>
                  <div className="text-xs text-muted-foreground mb-3">{teamMembers[3].specialty}</div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{teamMembers[3].bio}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Sebastians Ramirez — col-span-1 */}
          <div>
            <TeamCard member={teamMembers[4]} index={4} />
          </div>
        </div>

      </div>
    </section>
  );
}
